﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Automation;
using System.Diagnostics;

namespace EventChangeMonitor
{
    class Program
    {
        static Dictionary<int, Activity> activityList = new Dictionary<int, Activity>();
        static int lastProcessID = 0;

        static void Main(string[] args)
        {
            Automation.AddAutomationFocusChangedEventHandler(OnFocusChangedHandler);
            Console.ReadLine();
        }

        private static void OnFocusChangedHandler(object src, AutomationFocusChangedEventArgs args)
        {
            Console.WriteLine("Focus changed!");
            AutomationElement element = src as AutomationElement;
            if (element != null)
            {
                // string name = element.Current.Name;
                // string id = element.Current.AutomationId;
                int processId = element.Current.ProcessId;

                Activity currentActivity = null;
                if (activityList.ContainsKey(processId))
                {
                    currentActivity = activityList[processId];
                    activityList.Remove(processId);
                }
                else
                {
                    currentActivity = new Activity();
                }

                

                using (Process process = Process.GetProcessById(processId))
                {
                    currentActivity.processName = process.ProcessName;
                    currentActivity.name = process.MainWindowTitle;
                }

                /* Start time is current system time */
                DateTime startTime = DateTime.Now;
                currentActivity.startTime = startTime;


                if (activityList.ContainsKey(lastProcessID))
	            {
	                activityList[lastProcessID].endTime = startTime;
                    activityList[lastProcessID].generateDuration();
	            }

                activityList.Add(processId,currentActivity);
                lastProcessID = processId;
            }
            Console.WriteLine("-------------------------------------------------------------------------------");
            foreach (KeyValuePair<int, Activity> pair in activityList)
            {
                Console.WriteLine("Process ID : {0}, Window Name : {1}, Process Name : {2}, Duration : {3}", pair.Key, pair.Value.name, pair.Value.processName, pair.Value.duration);
            }
            Console.WriteLine("-------------------------------------------------------------------------------");
        }
    }
}
